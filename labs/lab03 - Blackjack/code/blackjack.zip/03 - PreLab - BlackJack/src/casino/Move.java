package casino;

public enum Move {
	HIT, STAY, DOUBLE;
}
