package casino;

/**
 * A stack of more than one deck used in a casino game
 *
 */
public class DeckStack {
	
	public DeckStack(int numDecks) {
		
	}
	
	public Card dealTopCard() {
		
	}
	
	protected void restoreDecks() {
		
	}
	
	public int cardsLeft() {
		
	}
	
	
}
