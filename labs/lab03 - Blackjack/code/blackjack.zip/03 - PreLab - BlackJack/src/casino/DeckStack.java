package casino;

/**
 * A stack of more than one deck used in a casino game
 *
 */
public class DeckStack {

	private Deck[] decks;
	
	public DeckStack(int numDecks) {
		//TODO: Complete this constructor
	}
	
	public Card dealTopCard() {
		//TODO: Deal the top card
		return null;
	}
	
	protected void restoreDecks() {
		//TODO: Restock and reshuffle all of the decks
	}
	
	public int cardsLeft() {
		//TODO: Return the number of cards left that can be dealt
	}
	
	
}
