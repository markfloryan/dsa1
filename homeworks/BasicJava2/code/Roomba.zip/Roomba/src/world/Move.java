package world;

public enum Move{
	FORWARD, TURNCLOCKWISE, TURNCOUNTERCLOCKWISE;
};
